# bot/main.py - Secure-ready Avaniya ArtBot demo
# IMPORTANT: This demo DOES NOT store private keys or sign transactions server-side.
# Wallet auth is client-side (signature). For any real payments, use multisig (Gnosis Safe) + manual admin approval.

import os, asyncio, time, secrets
from aiogram import Bot, Dispatcher, types, executor
from aiohttp import web
from eth_account.messages import encode_defunct
from eth_account import Account
import asyncpg

BOT_TOKEN = os.getenv('BOT_TOKEN')  # required
VERIFY_SECRET = os.getenv('VERIFY_SECRET', 'change_this_random_secret')
DATABASE_URL = os.getenv('DATABASE_URL', 'postgresql://postgres:password@postgres:5432/stakerbot')
WEBAPP_BASE = os.getenv('WEBAPP_BASE', 'https://your-webapp.example')
NONCE_TTL = int(os.getenv('NONCE_TTL', '300'))

if not BOT_TOKEN:
    raise RuntimeError('BOT_TOKEN is required in env')

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(bot)
db_pool = None

async def init_db():
    global db_pool
    db_pool = await asyncpg.create_pool(DATABASE_URL)
    async with db_pool.acquire() as conn:
        await conn.execute('''
            CREATE TABLE IF NOT EXISTS nonces (
                chat_id BIGINT PRIMARY KEY,
                nonce TEXT,
                expires_at BIGINT
            );
        ''')
        await conn.execute('''
            CREATE TABLE IF NOT EXISTS verified (
                chat_id BIGINT PRIMARY KEY,
                address TEXT,
                verified_at BIGINT
            );
        ''')

@dp.message_handler(commands=['start','help'])
async def cmd_start(message: types.Message):
    await message.reply('سلام 👋 این ربات Avaniya (دموی اتصال کیف‌پول) است. برای اتصال /connect را ارسال کنید.')

@dp.message_handler(commands=['connect'])
async def cmd_connect(message: types.Message):
    chat_id = message.chat.id
    nonce = secrets.token_hex(16)
    expires_at = int(time.time()) + NONCE_TTL
    async with db_pool.acquire() as conn:
        await conn.execute('''INSERT INTO nonces(chat_id, nonce, expires_at)
                              VALUES($1,$2,$3)
                              ON CONFLICT (chat_id) DO UPDATE SET nonce=EXCLUDED.nonce, expires_at=EXCLUDED.expires_at;''',
                           chat_id, nonce, expires_at)
    link = f"{WEBAPP_BASE}/connect?chat_id={chat_id}&nonce={nonce}"
    await message.reply(f"برای اتصال کیف‌پول، لطفاً این لینک را باز کنید:\n{link}\n(این لینک {NONCE_TTL} ثانیه معتبر است)")

async def handle_verify(request):
    try:
        data = await request.json()
    except:
        return web.json_response({'ok':False,'error':'invalid_json'}, status=400)
    secret = data.get('secret')
    if secret != VERIFY_SECRET:
        return web.json_response({'ok':False,'error':'invalid_secret'}, status=403)
    try:
        chat_id = int(data.get('chat_id',0))
        nonce = data.get('nonce','')
        signature = data.get('signature','')
        address = data.get('address','')
    except Exception:
        return web.json_response({'ok':False,'error':'invalid_payload'}, status=400)

    async with db_pool.acquire() as conn:
        row = await conn.fetchrow('SELECT nonce, expires_at FROM nonces WHERE chat_id=$1', chat_id)
        if not row:
            return web.json_response({'ok':False,'error':'nonce_not_found'}, status=400)
        if row['nonce'] != nonce or int(row['expires_at']) < int(time.time()):
            return web.json_response({'ok':False,'error':'nonce_invalid_or_expired'}, status=400)

    try:
        msg = encode_defunct(text=nonce)
        recovered = Account.recover_message(msg, signature=signature)
        if recovered.lower() != address.lower():
            return web.json_response({'ok':False,'error':'signature_mismatch'}, status=400)
        async with db_pool.acquire() as conn:
            await conn.execute('''INSERT INTO verified(chat_id,address,verified_at)
                                  VALUES($1,$2,$3)
                                  ON CONFLICT (chat_id) DO UPDATE SET address=EXCLUDED.address, verified_at=EXCLUDED.verified_at;''',
                               chat_id, address, int(time.time()))
        loop = asyncio.get_event_loop()
        loop.create_task(bot.send_message(chat_id, f"✅ آدرس کیف‌پول با موفقیت تایید شد:\n{address}"))
        return web.json_response({'ok':True})
    except Exception as e:
        return web.json_response({'ok':False,'error':str(e)}, status=500)

async def start_web():
    app = web.Application()
    app.router.add_post('/verify', handle_verify)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, '0.0.0.0', 8080)
    await site.start()

if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    loop.run_until_complete(init_db())
    loop.create_task(start_web())
    executor.start_polling(dp, skip_updates=True)