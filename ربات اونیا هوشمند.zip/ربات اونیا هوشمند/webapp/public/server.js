const express = require('express');
const path = require('path');
const fetch = require('node-fetch');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const BOT_VERIFY_ENDPOINT = process.env.BOT_VERIFY_ENDPOINT || 'http://bot:8080/verify';

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname,'public')));

// تزریق VERIFY_SECRET از ENV به HTML
const indexPath = path.join(__dirname,'public','index.html');
app.get('*', (req, res) => {
  fs.readFile(indexPath, 'utf8', (err, data) => {
    if(err) return res.status(500).send('Error loading page');
    const updated = data.replace(
      'content="replace_with_random"',
      `content="${process.env.VERIFY_SECRET}"`
    );
    res.send(updated);
  });
});

// endpoint برای دریافت امضا
app.post('/submit', async (req,res)=>{
  try{
    const resp = await fetch(BOT_VERIFY_ENDPOINT, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(req.body)
    });
    const j = await resp.json();
    res.json(j);
  }catch(e){
    res.status(500).json({ok:false,error:e.message});
  }
});

app.listen(PORT, ()=>console.log('webapp listening on',PORT));